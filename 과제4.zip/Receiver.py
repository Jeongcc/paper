import socket
import time
import random

class Receiver:
    def __init__(self):
        # 호스트와 포트 번호 초기화
        self.host = ''
        self.port = 10080

        self.packet_loss_prob = float(input('packet loss probability: '))

        self.rwnd = 1000
        self.start_times = {}
        self.sequence_number = {}
        self.buffers = {}

        self.dest_files = {}
        self.log_files = {}

    def create_socket(self):
        # UDP 소켓 생성
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind((self.host, self.port))
        # Receive buffer size 설정
        print('socket recv buffer size:', self.socket.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF))
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 10000000)
        print('socket recv buffer size updated:', self.socket.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF))
        print()
        print('receiver program starts...')

    def receive(self):
        while True:
            message, address = self.socket.recvfrom(1400)

            flag = message[:1].decode()
            packet_number = int(message[1:7].decode())
            file_name_length = int(message[7:10].decode())
            file_name = message[10:10 + file_name_length].decode()
            data = message[10 + file_name_length:]

            # Complete transporting
            if flag == 'E':
                goodput = packet_number / (time.time() - self.start_times[file_name])

                self.dest_files[file_name].close()
                
                self.log_files[file_name].write('\nFile transfer is finished.')
                self.log_files[file_name].write('\nThroughput: {0:.2f} pkts / sec'.format(goodput))
                self.log_files[file_name].close()
                continue
            
            # Initialize a file
            elif flag == 'S':
                self.start_times[file_name] = time.time()
                self.sequence_number[file_name] = 0
                self.buffers[file_name] = [b'' for i in range(self.rwnd)]
                
                self.dest_files[file_name] = open(file_name, 'wb')
                self.dest_files[file_name].close()
                self.dest_files[file_name] = open(file_name, 'ab')
                
                self.log_files[file_name] = open(file_name + '_receiving_log.txt', 'w')
                self.log_files[file_name].close()
                self.log_files[file_name] = open(file_name + '_receiving_log.txt', 'a')
                
            # Log received packet
            self.log_files[file_name].write('{0:10.3f} pkt: {1:6d} | received\n'.format(time.time() - self.start_times[file_name], packet_number))

            # Compulsive packet loss
            if random.random() <= self.packet_loss_prob:
                self.log_files[file_name].write('{0:10.3f} pkt: {1:6d} | dropped\n'.format(time.time() - self.start_times[file_name], packet_number))
                continue

            # In-order
            if packet_number == self.sequence_number[file_name]:
                while True:
                    # Write data to the file
                    self.dest_files[file_name].write(data)

                    # Sliding window until find not received(stored) data
                    self.sequence_number[file_name] += 1
                    del self.buffers[file_name][0]
                    self.buffers[file_name].append(b'')
                    
                    if self.buffers[file_name][0] == b'':
                        break

                    data = self.buffers[file_name][0]
                
                # Send cumulative ACK
                packet_number = self.sequence_number[file_name] - 1
            # Out of order
            else:
                # Ignore a strange packet
                if packet_number - self.sequence_number[file_name] >= self.rwnd:
                    continue
                elif self.sequence_number[file_name] - packet_number >= self.rwnd:
                    continue
                # Store the out of order data
                elif packet_number > self.sequence_number[file_name]:
                    self.buffers[file_name][packet_number - self.sequence_number[file_name]] = data
                    # Send duplicate ACK
                    packet_number = self.sequence_number[file_name] - 1

            # Log sent packet
            self.log_files[file_name].write('{0:10.3f} ACK: {1:6d} | sent\n'.format(time.time() - self.start_times[file_name], packet_number))
            
            self.socket.sendto((file_name + ':' + str(packet_number)).encode(), address)

receiver = Receiver()
receiver.create_socket()
receiver.receive()
