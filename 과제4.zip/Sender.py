import socket
import threading
import time

class Sender:
    def __init__(self):
        self.receiver_ip = input('Receiver IP address: ')
        self.receiver_port = 10080
        self.window_size = int(input('window size: '))
        self.timeout = float(input('timeout (sec): '))

        self.start_times = {}
        self.left_windows = {}
        self.windows = {}
        self.last_packet = {}
        self.duplicated_packet_count = {}
        self.goodput = {}
        self.log_files = {}
        self.is_done = {}

        self.lock = threading.Lock()

    def create_socket(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def send(self, file_name):
        self.start_times[file_name] = time.time()
        self.left_windows[file_name] = 0
        self.windows[file_name] = []
        self.last_packet[file_name] = -99
        self.duplicated_packet_count[file_name] = 0
        self.goodput[file_name] = -1
        self.is_done[file_name] = False

        packet_number = 0
        
        self.log_files[file_name] = open(file_name + '_sending_log.txt', 'w')
        self.log_files[file_name].close()
        self.log_files[file_name] = open(file_name + '_sending_log.txt', 'a')
        source_file = open(file_name, 'rb')

        while True:
            # Timeout
            self.lock.acquire()
            if len(self.windows[file_name]) > 0:
                if time.time() - self.windows[file_name][0][1] >= self.timeout:
                    message = self.windows[file_name][0][0]
                    re_packet_number = self.left_windows[file_name]

                    self.log_files[file_name].write('{0:10.3f} pkt: {1:6d} | timeout since {2:10.3f}\n'.format(time.time() - self.start_times[file_name], re_packet_number, self.windows[file_name][0][1] - self.start_times[file_name]))
                    self.log_files[file_name].write('{0:10.3f} pkt: {1:6d} | retransmitted\n'.format(time.time() - self.start_times[file_name], re_packet_number))

                    self.windows[file_name][0][1] = time.time()
                    self.lock.release()

                    self.socket.sendto(message, (self.receiver_ip, self.receiver_port))
                    continue
            self.lock.release()

            # Window full
            if packet_number - self.left_windows[file_name] >= self.window_size:
                continue

            header = 'M'
            header += '{0:06d}'.format(packet_number)
            header += '{0:03d}'.format(len(file_name))
            header += file_name

            if packet_number > 0:
                data = source_file.read(1400 - len(header))
                # Complete file reading
                if data == b'':
                    # Complete transporting
                    if packet_number == self.left_windows[file_name]:
                        header = header.replace('M', 'E', 1)
                        message = header.encode() + data
                        self.socket.sendto(message, (self.receiver_ip, self.receiver_port))
                        
                        self.goodput[file_name] = packet_number / (time.time() - self.start_times[file_name])
                        break
                    continue
            else:
                header = header.replace('M', 'S', 1)
                data = b''

            message = header.encode() + data

            self.lock.acquire()
            self.windows[file_name].append([message, time.time()])
            
            self.log_files[file_name].write('{0:10.3f} pkt: {1:6d} | sent\n'.format(time.time() - self.start_times[file_name], packet_number))
            self.lock.release()

            self.socket.sendto(message, (self.receiver_ip, self.receiver_port))

            packet_number += 1

        source_file.close()
        
        self.is_done[file_name] = True

        self.log_files[file_name].write('\nFile transfer is finished.')
        self.log_files[file_name].write('\nThroughput: {0:.2f} pkts / sec'.format(self.goodput[file_name]))
        self.log_files[file_name].close()

    def receive(self):
        self.socket.bind(('', 0))
        while True:
            message, address = self.socket.recvfrom(2048)

            message = message.decode()
            file_name = message.split(':')[0]
            packet_number = int(message.split(':')[1])

            if not self.is_done[file_name]:
                self.lock.acquire()
                self.log_files[file_name].write('{0:10.3f} ACK: {1:6d} | received\n'.format(time.time() - self.start_times[file_name], packet_number))
                
                # Three duplicated ACKs
                if self.duplicated_packet_count[file_name] == 2:
                    message = self.windows[file_name][0][0]
                    re_packet_number = self.left_windows[file_name]

                    self.log_files[file_name].write('{0:10.3f} pkt: {1:6d} | 3 duplicated ACKs\n'.format(time.time() - self.start_times[file_name], re_packet_number - 1))
                    self.log_files[file_name].write('{0:10.3f} pkt: {1:6d} | sent\n'.format(time.time() - self.start_times[file_name], re_packet_number))

                    self.socket.sendto(message, (self.receiver_ip, self.receiver_port))
                self.lock.release()

            # Handle normal packet
            if packet_number >= self.left_windows[file_name]:
                # Cumulative sliding
                cumulated = packet_number - self.left_windows[file_name] + 1
                self.left_windows[file_name] += cumulated

                self.lock.acquire()
                # Cumulative sliding
                for i in range(cumulated):
                    del self.windows[file_name][0]
                self.lock.release()

            # Handle duplicate packet
            if self.last_packet[file_name] == packet_number:
                self.duplicated_packet_count[file_name] += 1
            else:
                self.last_packet[file_name] = packet_number
                self.duplicated_packet_count[file_name] = 0

    def close_socket(self):
        self.socket.close()

    def get_filename(self):
        while True:
            file_name = input('file_name: ')
            sending_thread = threading.Thread(target = self.send, args = (file_name, ))
            sending_thread.start()

sender = Sender()
sender.create_socket()
thread = threading.Thread(target = sender.get_filename)
thread.start()
receiving_thread = threading.Thread(target = sender.receive)
receiving_thread.start()
